package com.cg.fdcommon.service;

import java.util.List;

import com.cg.fdcommon.beans.FeedbackCommon;

public interface FeedbackCommonService {

	void addFeedbackCommon(FeedbackCommon common);
	
	List<FeedbackCommon> getAllCustomer(int customerId);
	
	List<FeedbackCommon> getAllMerchant(int merchantId);
	
	void addResponse(int fId,String response) throws Exception;
	
}
