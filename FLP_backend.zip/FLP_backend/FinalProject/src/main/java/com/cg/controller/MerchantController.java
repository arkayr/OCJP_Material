package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Inventory;
import com.cg.bean.Merchant;
import com.cg.bean.Product;
import com.cg.exception.MerchantNotFoundException;
import com.cg.service.MerchantServiceImpl;

@RestController
@CrossOrigin(origins = "http://localhost:4200")

public class MerchantController {

	@Autowired
	MerchantServiceImpl service;

	@GetMapping("/getProducts/{mid}")
	public ResponseEntity<?> getProducts(@PathVariable("mid") int mid) {
		try {
			List<Product> products = service.showProducts(mid);
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		} catch (MerchantNotFoundException e) {
			return new ResponseEntity<String>("Merchant Not Found", HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/getmerchant/{mid}")
	public ResponseEntity<?> getMerchantDetails(@PathVariable("mid") int mid) {
		try {
			return new ResponseEntity<Merchant>(service.getMerchantdetails(mid), HttpStatus.OK);
		} catch (MerchantNotFoundException e) {
			return new ResponseEntity<String>("Merchant Not Found", HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/addProduct/{mid}/{catid}")
	public ResponseEntity<?> addProduct(@PathVariable("mid") int mid, @PathVariable("catid") int catid,
			@RequestBody Product product) {
		int productid = service.addProduct(product, catid, mid);
		return new ResponseEntity<Integer>(productid, HttpStatus.OK);
	}

	@GetMapping("/inventory/{mid}")
	public ResponseEntity<?> getInventory(@PathVariable("mid") int mid) {
		try {
			return new ResponseEntity<List<Inventory>>(service.getMerchantInventory(mid), HttpStatus.OK);
		} catch (MerchantNotFoundException e) {
			return new ResponseEntity<String>("Merchant Not Found", HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/products/delete/{productId}/{merchantId}")
	public ResponseEntity<ResponseObject> removeProduct(@PathVariable int productId,@PathVariable int merchantId){
		try {
			service.removeProduct(productId,merchantId);
			return new ResponseEntity<ResponseObject>(new ResponseObject("Deleted"),HttpStatus.OK);
		}
		catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<ResponseObject>(new ResponseObject("Failed"),HttpStatus.CONFLICT);
		}
		
	}
	
	@PutMapping("/inventory/update/{inventoryId}/{stock}")
	public ResponseEntity<Integer> updateInventory(@PathVariable int inventoryId,@PathVariable int stock){
		try {
			return new ResponseEntity<Integer>(service.updateStock(inventoryId, stock),HttpStatus.OK);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<Integer>(0,HttpStatus.OK);
		}
		
	}
	
	
}
