package com.cg.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Categories;
import com.cg.bean.Inventory;
import com.cg.bean.Merchant;
import com.cg.bean.Product;
import com.cg.dao.CategoryRepository;
import com.cg.dao.DBFileRepository;
import com.cg.dao.InventoryRepository;
import com.cg.dao.MerchantDAO;
import com.cg.dao.ProductDAO;
import com.cg.exception.MerchantNotFoundException;
import com.cg.exception.ProductNotFoundException;

@Service
@Transactional
public class MerchantServiceImpl implements MerchantOperation {
	
	@Autowired
	ProductDAO dao;
	@Autowired
	MerchantDAO dao1;
	@Autowired
	private MerchantDAO merchantRepo;

	@Autowired
	private ProductDAO productRepo;

	@Autowired
	private InventoryRepository inventoryRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private DBFileRepository dbFileRepository;
	
	@Override
	public List<Product> showProducts(int mid) throws MerchantNotFoundException {
		Optional<Merchant> merchant = merchantRepo.findById(mid);
		if (merchant.isPresent())
			return merchant.get().getProducts();
		else
			throw new MerchantNotFoundException("Merchant Not Found");
	}

	@Override
	public Merchant getMerchantdetails(int id) throws MerchantNotFoundException {
		Optional<Merchant> merchant = merchantRepo.findById(id);
		if (merchant.isPresent())
			return merchant.get();
		throw new MerchantNotFoundException("Merchant Not Found");
	}

	@Override
	public Merchant getMerchantById(int merchantId) throws MerchantNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer addProduct(Product product, int categoryId, int merchantId) {
		Optional<Categories> category = categoryRepository.findById(categoryId);
		product.setCategory(category.get());
		Optional<Merchant> merchant = merchantRepo.findById(merchantId);
		productRepo.save(product);
		merchant.get().getProducts().add(product);
		merchantRepo.save(merchant.get());
		Timestamp time = new Timestamp(System.currentTimeMillis());
		inventoryRepository.save(new Inventory(product, merchantId, 0, time));
		return product.getProductId();
	}

	@Override
	public List<Product> getAllProducts(int merchantId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProduct(Product product) throws ProductNotFoundException {
		// TODO Auto-generated method stub

	}

	@Override
	public Product getProductDetails(int productId) throws ProductNotFoundException {
		Optional<Product> product = productRepo.findById(productId);
		if (!product.isPresent())
			throw new ProductNotFoundException();
		return product.get();
	}

	@Override
	public void removeProduct(int productId,int merchantId) throws ProductNotFoundException {
		if(!productRepo.existsById(productId))
			throw new ProductNotFoundException();
		else {
			
			Product product = productRepo.findById(productId).get();
			Merchant merchant = merchantRepo.findById(merchantId).get();
			Inventory inven = inventoryRepository.getInventory(productId);
			inventoryRepository.delete(inven);
			merchant.getProducts().remove(product);
			merchantRepo.save(merchant);
			/*
			 * List<String> urls = dbFileRepository.getAllProductImages(productId); for
			 * (String string : urls) { dbFileRepository.deleteById(string); }
			 */
		}
			
			
			

	}

	@Override
	public List<Inventory> getMerchantInventory(int merchantId) throws MerchantNotFoundException {
		if (!merchantRepo.existsById(merchantId))
			throw new MerchantNotFoundException("Merchant Not Found");
		return inventoryRepository.getMerchantInventory(merchantId);
	}

	@Override
	public int updateStock(int inventoryId,int stock) throws Exception {
		Optional<Inventory> inventory = inventoryRepository.findById(inventoryId);
		if(!inventory.isPresent())
			throw new Exception("Inventory not found");
		else {
			inventory.get().setStock(stock);
			inventoryRepository.save(inventory.get());
			return stock;
		}
	}

}
