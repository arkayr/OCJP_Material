package com.cg.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bean.Inventory;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Integer> {

	@Query("from Inventory where merchant_id=:mid")
	public List<Inventory> getMerchantInventory(@Param("mid") int mid);

	@Query("from Inventory where product.productId=:productId")
	public Inventory getInventory(@Param("productId") int productId);
}
