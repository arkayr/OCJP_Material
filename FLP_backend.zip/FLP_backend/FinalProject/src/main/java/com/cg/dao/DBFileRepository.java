package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bean.Images;

@Repository
public interface DBFileRepository extends JpaRepository<Images, String> {

	@Query("select id from Images where productID=:productID")
	public List<String> getAllProductImages(@Param("productID") int productID);
	
	@Query("Delete from Images where productID=:productID")
	public List<String> deleteAllProductImages(@Param("productID") int productID);
}
