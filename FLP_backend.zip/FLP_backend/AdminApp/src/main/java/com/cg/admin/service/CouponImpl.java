package com.cg.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.admin.beans.CouponCode;
import com.cg.admin.dao.CouponDAO;



@Service
@Transactional
public class CouponImpl implements CouponService{

	@Autowired
	CouponDAO couponDao;
	
	@Override
	public void addCoupon(CouponCode coupon) {
		// TODO Auto-generated method stub
		couponDao.save(coupon);	
		
	}

	@Override
	public List<CouponCode> getAllCoupon() {
		// TODO Auto-generated method stub
		return couponDao.findAll();
	}


	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteCoupon(int id) {
		// TODO Auto-generated method stub
		if (couponDao.existsById(id)) {
			couponDao.deleteById(id);
		} else {
			System.out.println("Id not found");
		}
	}
}
