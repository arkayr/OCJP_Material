package com.cg.admin.beans;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name="coupon")
public class CouponCode {
	@Id
	@SequenceGenerator(name = "coupon_id",sequenceName = "coupon_id",initialValue = 250000,allocationSize = 1)
	@GeneratedValue(generator = "coupon_id")
	private Integer couponId;
	
	@Column(length=20)
	private String couponCode;
	
	private Date startdate;
	
	private Date enddate;
	
	private Double amount;

	public CouponCode() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CouponCode(Integer couponId, String couponCode, Date startdate, Date enddate, Double amount) {
		super();
		this.couponId = couponId;
		this.couponCode = couponCode;
		this.startdate = startdate;
		this.enddate = enddate;
		this.amount = amount;
	}
	
	public CouponCode( String couponCode, Date startdate, Date enddate, Double amount) {
		super();
		this.couponCode = couponCode;
		this.startdate = startdate;
		this.enddate = enddate;
		this.amount = amount;
	}

	public Integer getCouponId() {
		return couponId;
	}

	public void setCouponId(Integer couponId) {
		this.couponId = couponId;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "CouponCode [couponId=" + couponId + ", couponCode=" + couponCode + ", startdate=" + startdate
				+ ", enddate=" + enddate + ", amount=" + amount + "]";
	}
	
	
	
	
	
}
