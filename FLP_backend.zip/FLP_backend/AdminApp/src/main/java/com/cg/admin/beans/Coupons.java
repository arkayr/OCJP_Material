package com.cg.admin.beans;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Coupons {
	@Id
	@SequenceGenerator(name = "coup_id", sequenceName = "coup_id", initialValue = 3000, allocationSize = 1)
	@GeneratedValue(generator = "coup_id")
	private int couponId;
	private String couponCode;
	private float discount;
	private String imageUrl;
	private Date endDate;

	public Coupons() {
		super();
	}

	public Coupons(int couponId, String couponCode, float discount, String imageUrl, Date endDate) {
		super();
		this.couponId = couponId;
		this.couponCode = couponCode;
		this.discount = discount;
		this.imageUrl = imageUrl;
		this.endDate = endDate;
	}

	public int getCouponId() {
		return couponId;
	}

	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "Coupons [couponId=" + couponId + ", couponCode=" + couponCode + ", discount=" + discount + ", imageUrl="
				+ imageUrl + ", endDate=" + endDate + "]";
	}

	
	

}
