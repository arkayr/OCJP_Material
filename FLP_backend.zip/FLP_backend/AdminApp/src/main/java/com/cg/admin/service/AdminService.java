package com.cg.admin.service;

import java.util.List;
import java.util.Map;

import com.cg.admin.beans.Customer;
import com.cg.admin.beans.Merchant;
import com.cg.admin.beans.Product;

public interface AdminService {

	List<Customer> getAllCustomers();
	
	Customer addCustomer(Customer customer);
	
	Product addProduct(Product product);
	
	List<Product> getAllProducts();
	
	Map<String,Long> countData();
	
	List<Merchant> getAllMerchants();
	
	public Merchant addMerchant(Merchant merchant);
	
	public String DeleteMerchant(int merchantId);
	

}
