package com.cg.admin.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
@Entity
public class Inventory {
	@Id
	@SequenceGenerator(name = "inv_id", sequenceName = "inv_id", initialValue = 20000, allocationSize = 1)
	@GeneratedValue(generator = "inv_id")
	private int inventoryId;
	private int ProductID;
	private int stock;
	private String lastUpdated;

	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Inventory(int inventoryId, int productID, int stock, String lastUpdated) {
		super();
		this.inventoryId = inventoryId;
		ProductID = productID;
		this.stock = stock;
		this.lastUpdated = lastUpdated;
	}

	public int getInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		ProductID = productID;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	@Override
	public String toString() {
		return "Inventory [inventoryId=" + inventoryId + ", ProductID=" + ProductID + ", stock=" + stock
				+ ", lastUpdated=" + lastUpdated + "]";
	}

}
