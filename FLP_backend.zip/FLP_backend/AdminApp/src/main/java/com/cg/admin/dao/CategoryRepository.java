package com.cg.admin.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.admin.beans.Categories;

public interface CategoryRepository extends JpaRepository<Categories, Integer> {

}
