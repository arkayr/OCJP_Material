package com.cg.admin.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.admin.beans.Customer;
import com.cg.admin.beans.Merchant;
import com.cg.admin.beans.Product;
import com.cg.admin.dao.CustomerRepository;
import com.cg.admin.dao.MerchantRepository;
import com.cg.admin.dao.OrderRepository;
import com.cg.admin.dao.ProductRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private MerchantRepository merchantRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public Customer addCustomer(Customer customer) {
		customerRepository.save(customer);
		return customer;
	}

	@Override
	public Product addProduct(Product product) {
		productRepository.save(product);
		return product;
	}

	@Override
	public List<Product> getAllProducts() {

		return productRepository.findAll();
	}

	@Override
	public Map<String, Long> countData() {
		Map<String, Long> map = new HashMap<>();
		map.put("merchants", merchantRepository.count());
		map.put("customers", customerRepository.count());
		map.put("orders", orderRepository.count());
		return map;
	}

	@Override
	public List<Merchant> getAllMerchants() {
		return merchantRepository.findAll();
	}

	@Override
	public Merchant addMerchant(Merchant merchant) {
		merchantRepository.save(merchant);
		return merchant;
	}

	@Override
	public String DeleteMerchant(int merchantId) {
		merchantRepository.deleteById(merchantId);
		return "Deleted";
	}

}
