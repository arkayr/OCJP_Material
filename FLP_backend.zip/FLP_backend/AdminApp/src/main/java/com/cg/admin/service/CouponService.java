package com.cg.admin.service;

import java.util.List;

import com.cg.admin.beans.CouponCode;

public interface CouponService {
	public void addCoupon(CouponCode coupon);
	public void deleteCoupon(int id);
	public List<CouponCode> getAllCoupon();
}
