package com.cg.admin.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.admin.beans.CouponCode;

public interface CouponDAO extends JpaRepository<CouponCode, Integer>{

}
