package com.cg.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.admin.beans.CouponCode;
import com.cg.admin.beans.Customer;
import com.cg.admin.beans.Merchant;
import com.cg.admin.beans.Product;
import com.cg.admin.service.AdminService;
import com.cg.admin.service.CouponService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value = "/admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
	@Autowired
	private CouponService couponService;
	
	@PostMapping(value = "/addCouponcode", consumes = { "application/json" }) // to add session into the database
	public ResponseEntity<?> save(@RequestBody CouponCode p) {	
		couponService.addCoupon(p);
		return new ResponseEntity<String>("Promoadded!",HttpStatus.OK);
	}
	@GetMapping("/AllCouponcodes") // Get mapping for getting list of sessions
	public List<CouponCode>  getAllCoupon() {
		return couponService. getAllCoupon();
	}

	@DeleteMapping(value = "/deletecouponCode/{id}") // to delete session from database using id
	public String deleteCoupon(@PathVariable int id) {
		couponService.deleteCoupon(id);
		return "Promo deleted";
	}

	@GetMapping("/customers")
	public List<Customer> getAllCustomers() {
		return adminService.getAllCustomers();
	}
	
	@PostMapping("/customers")
	public Customer addCustomer(@RequestBody Customer customer) {
		return adminService.addCustomer(customer);
	}
	
	@GetMapping("/products")
	public List<Product> getAllProducts() {
		return adminService.getAllProducts();
	}
	
	@PostMapping("/products")
	public Product addProduct(@RequestBody Product product) {
		return adminService.addProduct(product);
	}
	@GetMapping("/count")
	public Map<String,Long> count(){
		return adminService.countData();
	}
	
	@GetMapping("/merchants")
	public List<Merchant> getAllMerchants(){
		return adminService.getAllMerchants();
	}
	
	@PostMapping("/merchant/add")
	public Merchant addMerchant(@RequestBody Merchant merchant) {
		System.out.println(merchant);
		return adminService.addMerchant(merchant);
	}

	@DeleteMapping("/merchant/{id}")
	public ResponseEntity<Map<String,String>> deleteMerchantById(@PathVariable int id)  {
		adminService.DeleteMerchant(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
