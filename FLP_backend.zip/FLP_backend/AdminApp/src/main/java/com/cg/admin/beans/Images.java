package com.cg.admin.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Images {
	@Id
	@SequenceGenerator(name = "img_id", sequenceName = "img_id", initialValue = 100000, allocationSize = 1)
	@GeneratedValue(generator = "img_id")
	private int imageId;
	private String imageUrl;
	// private int productId;
	public Images() {
		super();
	}

	public Images(int imageId, String imageUrl) {
		super();
		this.imageId = imageId;
		this.imageUrl = imageUrl;
	}

	public int getImageId() {
		return imageId;
	}

	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "Images [imageId=" + imageId + ", imageUrl=" + imageUrl + "]";
	}

}
