import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerfeedbackComponent } from './customerfeedback/customerfeedback.component';


const routes: Routes = [
  {
    path:'customer',
    component:CustomerfeedbackComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
