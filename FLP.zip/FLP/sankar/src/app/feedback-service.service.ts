import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FeedbackServiceService {

  
  constructor(private http: HttpClient) { }

  baseUri = "http://192.168.0.101:6500/";

  addFeedBack(feedback: any): Observable<any> {
    return this.http.post(this.baseUri + "addFeedback", feedback);
  }

  getCustomer(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUri + "feedback/customer/" + 100);
  }

  getMerchant(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUri + "feedback/merchant/" + 1000);
  }

  addResponse(fid: number, response: string): Observable<any> {
    return this.http.get<any[]>(this.baseUri + "feedback/response/" + fid + "/" + response);
  }
}
