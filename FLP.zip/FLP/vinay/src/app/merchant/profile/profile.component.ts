import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../../merchant.service';
import { Merchant } from '../../merchant';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private merchantService:MerchantService) { }
  merchantDetails:Merchant;
  ngOnInit() {
    this.merchantService.getMerchantDetails().subscribe(data=>{
      this.merchantDetails=data;
      console.log(this.merchantDetails);
    },error=>{
      console.log(error);
      alert("failed to get Data");
    })
  }

}
