import { Component, OnInit } from '@angular/core';
import { MerchantService } from 'src/app/merchant.service';
import { Inventory } from 'src/app/inventory';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-inventory',
  templateUrl: './my-inventory.component.html',
  styleUrls: ['./my-inventory.component.css']
})
export class MyInventoryComponent implements OnInit {

  constructor(private merchantService: MerchantService,private route:Router) { }
  inventory: Inventory[];
  ngOnInit() {
    this.merchantService.getInventory().subscribe(res => {
      this.inventory = res;
    },error=>{
      alert("Failed to fetch Data");
    })
  }

  navigate(id:number,name:string,stock:number){
    this.route.navigateByUrl('/merchant/updatestock/'+id+'/'+name+'/'+stock);
  }
}
