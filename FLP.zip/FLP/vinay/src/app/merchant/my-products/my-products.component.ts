import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../../merchant.service';
import { Product } from '../../product';
import { Route, Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-my-products',
  templateUrl: './my-products.component.html',
  styleUrls: ['./my-products.component.css']
})
export class MyProductsComponent implements OnInit {

  constructor(private merchantService:MerchantService,private router:Router) { }
  products:Product[];
  ngOnInit() {
    this.merchantService.getProducts().subscribe(data=>{
      this.products=data;
    },error=>{
      console.log(error);
    })
  }

  navigateto(){
    this.router.navigateByUrl("/merchant/addproduct")
  }

  uploadimage(id:number){
    this.router.navigateByUrl("/merchant/uploadImages/"+id);
  }

  delete(productId){
    if(confirm("Are you sure you want to remove")){
      this.merchantService.deleteProduct(productId).subscribe(data=>{
        alert("Deleted Successfully");
        this.ngOnInit();
      })
    }

  }
}
