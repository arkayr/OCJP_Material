import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MerchantService } from 'src/app/merchant.service';

@Component({
  selector: 'app-update-inventory',
  templateUrl: './update-inventory.component.html',
  styleUrls: ['./update-inventory.component.css']
})
export class UpdateInventoryComponent implements OnInit {

  constructor(private merchantService: MerchantService, private route: ActivatedRoute) { }

  id: number;
  productname: string;
  stock: number;

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params.id;
      this.productname = params.name;
      this.stock = params.stock;
      console.log(params);
    })
  }

  update() {
    this.merchantService.updateStock(this.id, this.stock).subscribe(res => {
      alert("updated Successfully");
    }, error => {
      alert("failed to update")
    })
  }
}
