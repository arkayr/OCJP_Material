import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Merchant } from './merchant';
import { AuthService } from './auth.service';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class MerchantService {

  baseUri = "http://192.168.0.101:5000/";

  constructor(private http: HttpClient, private authService: AuthService) { }

  getMerchantDetails(): Observable<Merchant> {
    return this.http.get<Merchant>(this.baseUri + "getmerchant/" + this.authService.getMerchantId())
  }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.baseUri + "getProducts/" + this.authService.getMerchantId())
  }

  addProduct(catId: number, product: any): Observable<any> {
    return this.http.post<any>(this.baseUri + "addProduct/" + this.authService.getMerchantId() + "/" + catId, product);
  }

  uploadImage(formData, productId):Observable<any> {
    return this.http.post(this.baseUri + 'uploadFile/' + productId, formData)
  }

  deleteProduct(productId: number): Observable<any> {
    return this.http.delete(this.baseUri + "products/delete/" + productId + "/" + this.authService.getMerchantId())
  }

  getInventory(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUri + "inventory/" + this.authService.getMerchantId())
  }

  updateStock(inventoryId: number, stock: number): Observable<number> {
    return this.http.put<number>(this.baseUri + 'inventory/update/' + inventoryId + '/' + stock, null);
  }
}
