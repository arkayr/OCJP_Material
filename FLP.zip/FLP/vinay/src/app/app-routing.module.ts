import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyProductsComponent } from './merchant/my-products/my-products.component';
import { MyInventoryComponent } from './merchant/my-inventory/my-inventory.component';
import { ProfileComponent } from './merchant/profile/profile.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './merchant/home/home.component';
import { MerchantComponent } from './merchant/merchant.component';
import { AddproductComponent } from './merchant/addproduct/addproduct.component';
import { UploadImagesComponent } from './merchant/upload-images/upload-images.component';
import { UpdateInventoryComponent } from './merchant/update-inventory/update-inventory.component';


const routes: Routes = [
  {
    path: '', redirectTo: '/merchant', pathMatch: "full"
  },
  {
    path: 'merchant',
    component: MerchantComponent,
    children: [
      { path: 'myproducts', component: MyProductsComponent },
      { path: 'addproduct', component: AddproductComponent },
      { path: 'myinventory', component: MyInventoryComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'Logout', component: LogoutComponent },
      { path: 'home', component: HomeComponent }, {
        path: 'uploadImages/:id', component: UploadImagesComponent
      },{
        path:'updatestock/:id/:name/:stock',component:UpdateInventoryComponent
      }
      
    ]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [MyProductsComponent, MyInventoryComponent, ProfileComponent, LogoutComponent, HomeComponent]