import { Product } from './product';
import { Timestamp } from 'rxjs';

export interface Inventory {
    inventory_Id:number,
    product:Product,
    merchant_id:number,
    stock:number,
    lastUpdated:Timestamp<any>,
}
