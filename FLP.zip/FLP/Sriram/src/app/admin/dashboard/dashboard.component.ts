import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import * as CanvasJS from '../../../assets/canvasjs.min.js';
import { AdminService } from '../admin.service.js';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private adminService:AdminService) { }


  merchants= 0;
  customers= 0;
  orders= 0;

  ngOnInit() {
    this.adminService.getCount().subscribe(data=>{
      console.log(data);
      this.merchants =  data.merchants;
      this.customers = data.customers;
      this.orders = data.orders;
      console.log(this.customers);  
      setTimeout(()=>{
        this.counter(); 
      },2000)

    })
    let dataPoints = [];
    let y = 0;
    for (var i = 0; i < 100; i++) {
      y += Math.round(Math.random());
      dataPoints.push({ x:y,y: y });
    }
    let chart = new CanvasJS.Chart("chartContainer", {
      animationEnabled: true,
      exportEnabled: true,
      title: {
        text: "Montly orders"
      },

      data: [
        {
          type: "line",
          dataPoints: dataPoints
        }]
    });

    chart.render();
    
  }

  //animation for customers and merchants list
  counter() {
    $('.counter-count').each(function () {
      $(this).prop('Counter', 0).animate({
        Counter: $(this).text()
      }, {
          duration: 5000,
          easing: 'swing',
          step: function (now) {
            $(this).text(Math.ceil(now));
          }
        });
    });
  }
}
