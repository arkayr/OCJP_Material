import { Component, OnInit } from '@angular/core';
import { Promo } from 'src/app/models/Promo';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addcoupon',
  templateUrl: './addcoupon.component.html',
  styleUrls: ['./addcoupon.component.css']
})
export class AddcouponComponent implements OnInit {

  promocodeId: number;
  couponcode: string;
  startdate: Date;
  enddate: Date;
  amount: string;
  prom: Promo
  constructor(private service: AdminService, private route: Router) { }
  ngOnInit() { }

  save() {
    var pro: Promo = new Promo(this.promocodeId, this.couponcode, this.startdate, this.enddate, this.amount);
    console.log(pro);
    this.service.addPromocode(pro).subscribe(data => {
      console.log(data);
    }, error => {
      console.log(error);
    })
  }

  ch = false;
  change() {
    this.ch = true;
  }

  backtopromoCode() {
    this.route.navigate(['admin/coupons']);
  }

  generateRandon() {
    this.couponcode = Math.random().toString(20).substring(2, 5) + Math.random().toString(20).substring(2, 5);
    this.couponcode = this.couponcode.toUpperCase();
  }
}
