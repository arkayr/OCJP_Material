import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../models/customer';
import { Observable } from 'rxjs';
import { Product } from '../models/product';
import { Merchant } from '../models/merchant';
import { Promo } from '../models/Promo';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  baseUri = "http://192.168.0.101:6500/admin/";

  constructor(private http: HttpClient) { }

  public getCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.baseUri + "customers");
  }

  public getproducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.baseUri + "products");
  }

  public getCount(): Observable<any> {
    return this.http.get<any>(this.baseUri + "count");
  }

  public getAllMerchants(): Observable<Merchant[]> {
    return this.http.get<Merchant[]>(this.baseUri + "merchants");
  }

  addPromocode(pro: Promo): Observable<Promo> {

    return this.http.post<Promo>(this.baseUri + "/addCouponcode", pro);
  }

  getPromocodes() {
    return this.http.get<Promo[]>(this.baseUri + "AllCouponcodes");
  }

  deletePromocode(promocodeId: number) {

    return this.http.delete<Promo>(this.baseUri + "deletecouponCode/" + promocodeId);

  }

  addMerchant(merchant: Merchant): Observable<any> {

    console.log(merchant);
    return this.http.post<Merchant>(this.baseUri + "merchant/add", merchant);

  }

  deleteMerchant(merchantId:number) {
    return this.http.delete<Merchant>(this.baseUri + "merchant/" + merchantId)

    //  this.merchants = this.merchants.filter(mer => mer.merchantId != code);

  }
}
