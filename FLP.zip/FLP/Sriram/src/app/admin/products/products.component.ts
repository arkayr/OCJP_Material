import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Product } from 'src/app/models/product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private adminService:AdminService) { }
  loaded:boolean=false
  products:Product[];
  ngOnInit() {
    this.adminService.getproducts().subscribe(data=>{
      this.products = data;
      console.log(this.products);
      this.loaded = true;
    })
  }

}
