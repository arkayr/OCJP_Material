import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Merchant } from 'src/app/models/merchant';

@Component({
  selector: 'app-merchants',
  templateUrl: './merchants.component.html',
  styleUrls: ['./merchants.component.css']
})
export class MerchantsComponent implements OnInit {

  constructor(private adminService: AdminService) { }
  loaded: boolean = false
  merchants: Merchant[];

  ngOnInit() {
    this.adminService.getAllMerchants().subscribe(data => {
      this.merchants = data;
      this.loaded = true;
    }, error => {
      alert("Failed to fetch data");
    })
  }

  delete(id: number) {
    if (confirm("Are you sure you want to delete")) {
      this.adminService.deleteMerchant(id).subscribe(res => {
        alert("Deleted Sucessfully");
        this.ngOnInit();
      }, error => {
        console.log(error);
        alert("Failed to delete Merchant");
      })
    }
  }
}
