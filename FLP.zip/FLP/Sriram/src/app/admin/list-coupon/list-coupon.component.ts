import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Promo } from 'src/app/models/Promo';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-coupon',
  templateUrl: './list-coupon.component.html',
  styleUrls: ['./list-coupon.component.css']
})
export class ListCouponComponent implements OnInit {

  constructor(private service: AdminService, private route: Router) { }
  prom: Promo[] = [];
  promoId: number = 0;
  ngOnInit(): void {
    //throw new Error("Method not implemented.");
    this.service.getPromocodes().subscribe(
      res => {
        this.prom = res;
        console.log(this.prom)

      },
      err => {
        alert("an error has occurred")
      }
    )
  }

  addPromocode() {
    this.route.navigate(['admin/addcoupon']);
  }

  deletePromocode(dat: number): any {
    //this.promoId = this.prom[data].couponId;
    if (this.service.deletePromocode(dat).subscribe(data => {
      console.log(data);
      this.ngOnInit();
    },
      error => {
        console.log(error);
        this.ngOnInit();
      }


    )) {
      if (confirm('Are you Sure You Want To Delete')) {
        this.prom.splice(dat, 1);
      }
    }
  }


  backtoadmin() {
    this.route.navigate(['coupon']);
  }

  sendmail() {
    alert("Mail sent to customers");
  }
}
