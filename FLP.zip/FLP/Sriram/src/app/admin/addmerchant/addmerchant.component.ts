import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/models/merchant';
import { AdminService } from '../admin.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-addmerchant',
  templateUrl: './addmerchant.component.html',
  styleUrls: ['./addmerchant.component.css']
})
export class AddmerchantComponent implements OnInit {

  constructor(private adminService: AdminService) { }
  public addMerchantForm: NgForm;
  merchants: Merchant[] = [];
  ngOnInit() {
  }

  onSubmit(merchant: Merchant) {
    console.log("hello" + merchant);
    this.adminService.addMerchant(merchant).subscribe(res=>{
      alert("Merchant Added successfully");
    },error=>{
      alert("Failed to add Merchant please try again");
    });
    
    //this.router.navigate(['/employees']);
  }
}
