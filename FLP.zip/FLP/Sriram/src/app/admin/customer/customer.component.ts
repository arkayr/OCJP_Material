import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Customer } from 'src/app/models/customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private adminService:AdminService) { }
  customers:Customer[];
  loaded:boolean=false;
  ngOnInit() {
    this.adminService.getCustomers().subscribe(data=>{
      console.log(data);
      this.customers = data;
      this.loaded = true;
    })
  }

}
