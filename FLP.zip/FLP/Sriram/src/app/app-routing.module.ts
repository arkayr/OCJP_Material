import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { MerchantsComponent } from './admin/merchants/merchants.component';
import { CustomerComponent } from './admin/customer/customer.component';
import { ProductsComponent } from './admin/products/products.component';
import { ListCouponComponent } from './admin/list-coupon/list-coupon.component';
import { AddcouponComponent } from './admin/addcoupon/addcoupon.component';
import { AddmerchantComponent } from './admin/addmerchant/addmerchant.component';


const routes: Routes = [
  {
    path: 'admin',
    component: AdminComponent,
    children: [
      {
        path: '', component: DashboardComponent
      }, {
        path: 'dashboard',
        component: DashboardComponent
      },
      {
        path: 'merchant',
        component: MerchantsComponent
      },
      {
        path: 'customer',
        component: CustomerComponent
      },
      {
        path: 'products',
        component: ProductsComponent
      },
      {
        path: 'coupons',
        component: ListCouponComponent
      },
      {
        path: 'addcoupon',
        component: AddcouponComponent
      },
      {
        path: 'addmerchant',
        component: AddmerchantComponent
      }
    ]
  }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
