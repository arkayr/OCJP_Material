export interface Merchant {
    merchantId:number,
    firstName:string,
    lastName:string,
    email:string,
    storeName:string,
    phone:string,
    revenue:number,
    isActive:boolean
}
