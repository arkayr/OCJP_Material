export class Promo{

  couponId:number;
  couponCode:string;
  startdate:Date;
  enddate:Date;
  amount:string;


  constructor(couponId,couponCode,startdate,enddate,amount)
  {
      this.couponId=couponId;
      this.couponCode=couponCode;
      this.startdate=startdate;
      this.enddate=enddate;
      this.amount=amount;
  }
}
