export interface Customer {
    customerId: number,
    firstName: string,
    lastName: string,
    phone: string,
    email: string,
    isActive: boolean
}

